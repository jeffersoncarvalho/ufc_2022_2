package ufcqx.teste;

public class TesteSD {
	
	public static void main(String[] args) {
		System.out.println("Teste Sistemas Distribu�dos!");
	}

}
