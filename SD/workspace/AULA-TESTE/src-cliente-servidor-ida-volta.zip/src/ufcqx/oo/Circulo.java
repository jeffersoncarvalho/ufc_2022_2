package ufcqx.oo;

public class Circulo extends Figura{

	@Override
	public void desenhar() {
		System.out.println("Circulo esta sendo desenhado!");
	}
}
