package ufcqx.oo;

public class Figura {

	public void desenhar() {
		System.out.println("Figura está sendo desenhada!");
	}
}
